package object

type HomeData struct {
	AdminName string
	Heros  []Loldatabase
}
