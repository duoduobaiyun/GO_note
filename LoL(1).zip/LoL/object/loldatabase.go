package object

type Loldatabase struct {
	Id string
	Name string
	Alias string
	Title string
	VoiceOne string
	VoiceTwo string
	Label string
	ImgUrl string
}
