package object

type HeroList struct{
	Hero []Hero
	Version string
	FileName string
	FileTime string
}
