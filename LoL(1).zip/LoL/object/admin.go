package object

type Admin struct {
	Id  int
	Name  string
	Pwd string
	Phone string
	Address string
}