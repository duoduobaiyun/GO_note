package object

type Hero struct {
	HeroId string
	Name string
	Alias string
	Title string
	Roles []string
	IsWeekFree string
	Attack string
	Defense string
	Magis string
	Difficulty string
	SelectAudio string
	BanAudio string
	IsARAMweekfree string
	Ispermanentweekfree string
	ChangeLabel string
}
