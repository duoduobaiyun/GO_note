package spider_lol

import (
	"LoL/object"
	"fmt"
)

func QueryAdmin(name, pwd string) (*object.Admin, error) {
	row:=SpiderDb.QueryRow("select admin_name, admin_phone, admin_addr from lolhero_admin where admin_name = ? and admin_pwd = ?",name,pwd)
	var admin object.Admin
	err :=row.Scan(&admin.Name,&admin.Phone,&admin.Address)
	if err !=nil{
		return nil,err
	}
	return &admin,nil
}

func Addadmin(name string,pwd string,phone string,addr string)(int64,error)  {
	result, err := SpiderDb.Exec("insert into " +
		"lolhero_admin (admin_name,admin_pwd,admin_phone,admin_addr)" +
		"values (?,?,?,?)",
		name,pwd,phone,addr)
	fmt.Println(1)
	if err != nil {
		return 0, err
	}
	rowId, err := result.RowsAffected()
	if err != nil {
		return 0, err
	}
	return rowId, nil
}