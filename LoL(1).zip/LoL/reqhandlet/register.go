package reqhandlet

import (
	"LoL/spider_lol"
	"fmt"
	"html/template"
	"net/http"
)

func RegisterPage(writer http.ResponseWriter, request *http.Request){
	temp,err :=template.ParseFiles("./views/register.html")
	if err!=nil {
		errtemp ,_:=template.ParseFiles("./views/error.html")
		errtemp.Execute(writer,err.Error())
	}
	temp.Execute(writer,nil)
}
func Register(writer http.ResponseWriter, request *http.Request) {

	err := request.ParseForm()
	if err!=nil {
		errtemp,_ := template.ParseFiles("./views/error.html")
		errtemp.Execute(writer,err.Error())
		return
	}

	userName := request.FormValue("username")
	userPwd := request.FormValue("userpwd")
	userPhone :=request.FormValue("userphone")
	userAddr :=request.FormValue("useraddr")
	fmt.Println(userName,userPwd)
	_,err=spider_lol.Addadmin(userName,userPwd,userPhone,userAddr)
	if err!=nil {
		errtemp ,_:=template.ParseFiles("./views/error.html")
		errtemp.Execute(writer,err.Error())
	}
	tempt,err :=template.ParseFiles("./views/index.html")
	tempt.Execute(writer,nil)
}
